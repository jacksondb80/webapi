using System;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WebApi.Models;
using WebApi.Repositories;
using WebApi.Services;

namespace WebApi.Controllers
{
     [Route("v1/pessoa")]
    public class PessoaController : Controller
    {
        
        /// <summary>
        /// Teste
        /// </summary>
        [HttpGet]
        [Route("teste")]
        [AllowAnonymous]
        public string Teste() => "Teste";        

    }
}