using System;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WebApi.Models;
using WebApi.Repositories;
using WebApi.Services;

namespace WebApi.Controllers
{
     [Route("v1/account")]
    public class HomeController : Controller
    {
        /// <summary>
        /// Index
        /// </summary>
        [HttpGet]
        [Route("index")]
        [AllowAnonymous]
        public async Task<string> IndexAsync()
        {
            var url = "https://localhost:5001/swagger/v1/swagger.json";//it should be the url of your api
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(url))
                {
                    using (var content = response.Content)
                    {  
                    //get the json result from your api
                        var result = await content.ReadAsStringAsync();
                        var root = (JObject)JsonConvert.DeserializeObject(result);                        
                        var items = root.SelectToken("paths").Children().OfType<JProperty>().ToDictionary(p => p.Name, p => p.Value);
                        foreach(var item in items)
                        {
                            Console.WriteLine(item.Key);
                            string[] partes = item.Key.Substring(1).Split('/');
                            foreach(string parte in partes) Console.WriteLine(parte);
                            var metodos = item.Value.SelectToken("").Children().OfType<JProperty>().ToDictionary(p => p.Name, p => p.Value);                            
                            foreach (var metodo in metodos)
                            {
                                var registros = metodo.Value.SelectToken("").Children().OfType<JProperty>().ToDictionary(p => p.Name, p => p.Value);
                                foreach (var registro in registros){
                                    if (registro.Key == "summary")                                    
                                        Console.WriteLine(registro.Value);
                                }
                                
                            }   
                                 
                        }
                    }
                }
            }
             
            return $"JDB API em execução: {DateTime.Now}";
        }

        /// <summary>
        /// Efetuar login na aplicação
        /// </summary>
        /// <param name="User"></param>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /User
        ///     {
        ///        "username": "usuario",
        ///        "password": "senha"
        ///     }
        /// </remarks>
        /// <returns>Usuario e Token</returns>
        /// <response code="200">Return User and Token</response>
        /// <response code="400">Bad Request</response>
        /// <response code="404">Not Found</response>
        /// <response code="500">Internal Server Error</response>
        [HttpPost]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Route("login")]
        [AllowAnonymous]
        public async Task<ActionResult<dynamic>> Authenticate([FromBody]User model)
        {
            var user = UserRepository.Get(model.Username, model.Password);

            if (user == null)
                return NotFound(new { message = "Usuário ou senha inválidos" });

            var token = TokenService.GenerateToken(user);
            user.Password = "";
            return new
            {
                user = user,
                token = token
            };
        }

        /// <summary>
        /// anonimo
        /// </summary>
        [HttpGet]
        [Route("anonymous")]
        [AllowAnonymous]
        public string Anonymous() => "Anônimo";

        /// <summary>
        /// Autenticado
        /// </summary>
        [HttpGet]
        [Route("authenticated")]
        [Authorize]
        public async Task<string> AuthenticatedAsync (){
            var claimsIdentity = User.Identity as ClaimsIdentity;
            var role = claimsIdentity.FindFirst(ClaimTypes.Role);
            var store = claimsIdentity.FindFirst("Store");
            try
            {
                await PessoaService.TesteAsync();

            }
            catch (System.Exception ex)
            {
                
                return  String.Format("Erro - {0} {1} {2}", User.Identity.Name, role.Value, ex.Message);
            }
            
            return  String.Format("Autenticado - {0} {1} {2}", User.Identity.Name, role.Value, store.Value);
        }

        /// <summary>
        /// empregado
        /// </summary>
        [HttpGet]
        [Route("employee")]
        [Authorize(Roles = "employee,manager")]
        public string Employee() => "Funcionário";

        /// <summary>
        /// gerente
        /// </summary>
        [HttpGet]
        [Route("manager")]
        [Authorize(Roles = "manager")]
        public string Manager() => "Gerente";

    }
}