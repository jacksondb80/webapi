using WebApi.Repositories;
using WebApi.Models;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace WebApi.Services
{
    public class PessoaService
    {
        public static async Task TesteAsync()
        {
            // create new Repository for table Users
            PessoaRepository pessoaRepository = new PessoaRepository("Pessoa");

            var pessoas = await pessoaRepository.GetAllSqlAsync("select * from pessoa");

            foreach(var item in pessoas.ToList()){
                Console.WriteLine($"Fetched User {item.FirstName}");
            }

            var pessoa = await pessoaRepository.GetSqlAsync($"select * from pessoa where id = 1");
            if (pessoa != null)
                Console.WriteLine($"Fetched User {pessoa.FirstName}");
           
           
            Console.WriteLine("Save into table Pessoa ");
            var guid = 2;
            await pessoaRepository.InsertAsync(new Pessoa()
            {
                FirstName = "Test2",
                Id = guid,
                LastName = "LastName2"
            });


            await pessoaRepository.UpdateAsync(new Pessoa()
            {
                FirstName = "Test3",
                Id = guid,
                LastName = "LastName3"
            });

            
            var pessoax = await pessoaRepository.GetAsync(guid);
            Console.WriteLine($"Fetched User {pessoax.FirstName}");
/*
            List<Pessoa> pessoas = new List<Pessoa>();

            for (var i = 0; i < 100; i++)
            {
                var id = Guid.NewGuid();
                pessoas.Add(new Pessoa
                {
                    Id = id,
                    LastName = "aaa",
                    FirstName = "bbb"
                });
            }

            var stopwatch = new Stopwatch();
            stopwatch.Start();
           
           
            Console.WriteLine($"Inserted {await pessoaRepository.SaveRangeAsync(pessoas)}");

            stopwatch.Stop();
            var elapsed_time = stopwatch.ElapsedMilliseconds;
            Console.WriteLine($"Elapsed time {elapsed_time} ms");
            */
        }
        
        
    }
}