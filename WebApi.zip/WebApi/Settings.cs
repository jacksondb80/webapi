namespace WebApi
{
    public static class Settings
    {
        public static string Secret = "jdbxf7d8863b48e197b9287d492b708e";
        //public static string Database = "MYSQL";
        //public static string DatabaseName = "Server=localhost;Database=webapi;User Id=root;Password=;";
        public static string Database = "SQLITE";
        public static string DatabaseName = "Data Source=WebApi.sqlite";

    }
}