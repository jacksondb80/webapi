using WebApi.Models;

namespace WebApi.Repositories
{
    public class PessoaRepository : GenericRepository<Pessoa>
    {
        public PessoaRepository(string tableName) : base(tableName)
        {
        
        }
    }
}