
using Dapper;
using Microsoft.Data.Sqlite;
using MySqlConnector;
using System;
using System.Linq;

namespace WebApi
{
    public class DatabaseBootstrap : IDatabaseBootstrap
    {
        private readonly string databaseConfig;
        private readonly string database;


        public DatabaseBootstrap()
        {
            this.databaseConfig = Settings.DatabaseName;
            this.database = Settings.Database;
        }

        public void Setup()
        {
            if(database == "SQLITE"){
                using var connection = new SqliteConnection(databaseConfig);
                var table = connection.Query<string>("SELECT name FROM sqlite_master WHERE type='table' AND name = 'Pessoa';");
                var tableName = table.FirstOrDefault();
                if (!string.IsNullOrEmpty(tableName) && tableName == "Pessoa")
                    return;

                connection.Execute("Create Table Pessoa (" +
                    "Id VARCHAR(100) NOT NULL," +
                    "FirstName VARCHAR(100) NOT NULL," +
                    "LastName VARCHAR(1000) NULL);");
            }else if(database == "MYSQL"){
                using var connection = new MySqlConnection(databaseConfig);
                var table = connection.Query<string>("SELECT table_name FROM information_schema.tables WHERE table_schema = 'webapi' and table_name = 'pessoa';");
                var tableName = table.FirstOrDefault();
                if (!string.IsNullOrEmpty(tableName) && tableName == "pessoa")
                    return;

                connection.Execute("Create Table Pessoa (" +
                    "Id VARCHAR(100) NOT NULL," +
                    "FirstName VARCHAR(100) NOT NULL," +
                    "LastName VARCHAR(1000) NULL);");
            }else{
                throw new Exception("Erro: Banco de dados não configurado.");
            }

            
        }
    }
}