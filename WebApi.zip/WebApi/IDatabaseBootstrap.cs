namespace WebApi
{
    public interface IDatabaseBootstrap
    {
        void Setup();
    }
}
