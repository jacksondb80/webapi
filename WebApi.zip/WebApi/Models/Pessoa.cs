using System;

namespace WebApi.Models
{
    public class Pessoa
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}